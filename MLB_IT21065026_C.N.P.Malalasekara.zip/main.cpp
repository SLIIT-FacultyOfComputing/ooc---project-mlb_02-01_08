 #include <iostream>
 #include"advertiser.h"
 #include<cstring>
#define SIZE 15;
using namespace std;
 
 




int main() {
  
   advertiser*advertiser1;
   
   advertiser1=new advertiser();
   
}